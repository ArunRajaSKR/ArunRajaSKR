<?php 
    session_start();
    $pageDetails = explode('/',$_SERVER['REQUEST_URI']);  
    $page = $pageDetails[2];
?>

<ul class="navbar-nav bg-gradient-primary sidebar sidebar-dark accordion" id="accordionSidebar">

    <!-- Sidebar - Brand -->
    <a class="sidebar-brand d-flex align-items-center justify-content-center" href="dashboard">
        <div class="sidebar-brand-text mx-3">Studio Booking</div>
    </a>

    <!-- Divider -->
    <hr class="sidebar-divider my-0">

    <?php if($_SESSION['userType'] == 1) { ?>
    <!-- Nav Item - Dashboard -->
    <li class="nav-item <?php if($page == 'dashboard') { echo 'active'; } ?>">
        <a class="nav-link" href="dashboard">
            <i class="fas fa-fw fa-tachometer-alt"></i>
            <span>Dashboard</span>
        </a>
    </li>
    <?php } ?>

    <!-- Nav Item - Pages Collapse Menu -->
    <li class="nav-item <?php if($page == 'booking') { echo 'active'; } ?>">
        <a class="nav-link" href="booking">
            <i class="fas fa-fw fa-list"></i>
            <span>Booking</span>
        </a>
    </li>

</ul>
<!-- End of Sidebar -->