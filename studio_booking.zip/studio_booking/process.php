<?php 
error_reporting(0);
require_once('config/dbconnect.php');

session_start();
$action = $_POST['action'];
$datetime = date("Y-m-d H:i:s"); 

switch($action) {
    case 'booking':
        
        $query = "insert into booking (userId, seatNo, bookingStatus, createdAt) value ('".$_SESSION['userId']."','".$_POST['seat_no']."',1,'".$datetime."') ";
        $result = $con->query($query);
        $last_id = $con->insert_id;

        echo json_encode(array("last_id"=>$last_id));
    break;
    case 'deactivate':
        
        $query = "insert into booking (userId, seatNo, bookingStatus, createdAt) value ('".$_SESSION['userId']."','".$_POST['seat_no']."',2,'".$datetime."') ";
        $result = $con->query($query);
        $last_id = $con->insert_id;

        echo json_encode(array("last_id"=>$last_id));
    break;
    default: 
        header("Location:booking");
}
?>