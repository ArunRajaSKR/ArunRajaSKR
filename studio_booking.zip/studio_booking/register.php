<?php error_reporting(0); 
    include('config/define.php');
    session_start();
    if($_SESSION['userId'] != null) { 
        if($_SESSION['userType'] == 1) { 
            echo "<script>window.location.href='".BASE_URL_PATH.'dashboard'."'</script>";
        } else if($_SESSION['userType'] == 2) { 
            echo "<script>window.location.href='".BASE_URL_PATH.'booking'."'</script>";
        }
    }
?>
<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Studio Booking - Registration</title>

    <link rel="shortcut icon" href="assets/img/logo.jpg">

    <!-- Custom fonts for this template-->
    <link href="assets/vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
    <link
        href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i"
        rel="stylesheet">

    <!-- Custom styles for this template-->
    <link href="assets/css/sb-admin-2.min.css" rel="stylesheet">

</head>

<body class="bg-gradient-primary">

    <div class="container">

        <!-- Outer Row -->
        <div class="row justify-content-center">

            <div class="col-xl-5 col-lg-6 col-md-4">

                <div class="card o-hidden border-0 shadow-lg my-4">
                    <div class="card-body p-0">
                        <!-- Nested Row within Card Body -->
                        <div class="row">
                            
                            <div class="col-lg-12">
                                <div class="p-5">
                                    <div class="text-center">
                                        <h1 class="h4 text-gray-900 mb-4">Create an Account!</h1>
                                    </div>
                                    <form class="user needs-validation" id="user-register-form" novalidate action="authenticate" method="post">

                                        <input type="hidden" name="action" value="register">

                                        <div class="form-group">
                                            <input type="text" class="form-control form-control-user" id="userName" name="userName" placeholder="User Name" required minlength="3" maxlength="32" value="<?php echo $_SESSION['userNameRegister']; ?>">
                                            <div class="valid-feedback">
                                                Looks good!
                                            </div>
                                            <div class="invalid-feedback">
                                                Please enter your name.
                                            </div>
                                        </div>
                                        <div class="form-group">
                                            <input type="email" class="form-control form-control-user" id="userEmail" name="userEmail" placeholder="Email Id" required maxlength="100" value="<?php echo $_SESSION['userEmailRegister']; ?>">
                                            <div class="valid-feedback">
                                                Looks good!
                                            </div>
                                            <div class="invalid-feedback">
                                                Invalid E-Mail Id.
                                            </div>
                                        </div>
                                        <div class="form-group">
                                            <input type="text" class="form-control form-control-user" id="userPhone" name="userPhone" placeholder="Phone No." required minlength="9" maxlength="15" onkeypress="return onlyNumeric(this.event);" value="<?php echo $_SESSION['userPhoneRegister']; ?>">
                                            <div class="valid-feedback">
                                                Looks good!
                                            </div>
                                            <div class="invalid-feedback">
                                                Invalid Mobile number.
                                            </div>
                                        </div>
                                        <div class="form-group">
                                            <input type="text" class="form-control form-control-user" id="userPassword" name="userPassword" placeholder="Password" required minlength="6" maxlength="12">
                                            <div class="valid-feedback">
                                                Looks good!
                                            </div>
                                            <div class="invalid-feedback">
                                                Please enter the password with 6 to 12 characters.
                                            </div>
                                        </div>
                                        <div class="form-group">
                                            <input type="password" class="form-control form-control-user" id="confirmPassword" name="confirmPassword" placeholder="Confirm Password" required minlength="6" maxlength="12">
                                            <div class="valid-feedback vf-cp">
                                                Looks good!
                                            </div>
                                            <div class="invalid-feedback ivf-cp">
                                                Password and Confirm password should be same.
                                            </div>
                                        </div>
                                        <input type="submit" class="btn btn-primary btn-user btn-block" value="Register" />
                                    </form>
                                    <hr>
                                    <div class="text-center">
                                        <a href="login">Already have an account? Login!</a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

            </div>

        </div>

    </div>

    <!-- Bootstrap core JavaScript-->
    <script src="assets/vendor/jquery/jquery.min.js"></script>
    <script src="assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

    <!-- Core plugin JavaScript-->
    <script src="assets/vendor/jquery-easing/jquery.easing.min.js"></script>

    <!-- Custom scripts for all pages-->
    <script src="assets/js/sb-admin-2.min.js"></script>

    <script>
        // Example starter JavaScript for disabling form submissions if there are invalid fields
        (function () {
        'use strict'

        // Fetch all the forms we want to apply custom Bootstrap validation styles to
        var forms = document.querySelectorAll('.needs-validation')

        // Loop over them and prevent submission
        Array.prototype.slice.call(forms)
            .forEach(function (form) {
            form.addEventListener('submit', function (event) {
                
                var failed = false;

                

                var pswd = $("#userPassword").val();
                var cnfmpswd = $("#confirmPassword").val(); 
                if ((pswd != cnfmpswd) || (cnfmpswd == '')) {
                    $(".vf-cp").css("display","none");
                    $(".ivf-cp").css("display","inline-block");
                    failed = true;
                } else {
                    $(".ivf-cp").css("display","none");
                    $(".vf-cp").css("display","inline-block");
                }

                if (form.checkValidity() === false) {
                    failed = true;
                }

                if (failed == true) {
                    event.preventDefault()
                    event.stopPropagation()
                }

                form.classList.add('was-validated')
            }, false)
            })
        })();

        function onlyNumeric(evt) {
            var val = event.which || event.keyCode;
            if((val < 48) || (val > 57)) {
                return false;
            }
        }

        $(document).ready(function() { 
            var emailExist = "<?php echo $_SESSION['userEmailRegisterExistMsg']; ?>";
            if(emailExist != '') {
                alert(emailExist);
            }

            var phoneExist = "<?php echo $_SESSION['userPhoneRegisterExistMsg']; ?>";
            if(phoneExist != '') {
                alert(phoneExist);
            }
        });
    </script>

</body>

</html>