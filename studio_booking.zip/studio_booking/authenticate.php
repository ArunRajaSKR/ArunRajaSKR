<?php 
error_reporting(0);
require_once('config/dbconnect.php');

session_start();
$action = $_POST['action'];
$datetime = date("Y-m-d H:i:s");

switch($action) {
    case 'register': 
        session_unset();

        $query = "SELECT
        (select COUNT(userEmail) FROM user WHERE userEmail = '".$_POST['userEmail']."') as existEmail, 
        (select COUNT(userPhone) FROM user WHERE userPhone = ".$_POST['userPhone'].") as existPhone";
        $result = $con->query($query);
        $exist_data = mysqli_fetch_assoc($result); 
        
        if(($exist_data['existEmail'] > 0) || ($exist_data['existPhone'] > 0)) {
            
            $_SESSION['userNameRegister'] = $_POST['userName'];
            $_SESSION['userEmailRegister'] = $_POST['userEmail'];
            $_SESSION['userPhoneRegister'] = $_POST['userPhone'];
            
            if($exist_data['existEmail'] > 0) {
               $_SESSION['userEmailRegisterExistMsg'] = 'Email Id already exist!'; 
            }
            if($exist_data['existPhone'] > 0) {
                $_SESSION['userPhoneRegisterExistMsg'] = 'Phone No. already exist!'; 
            }
            
            header("Location:register");
        } else {
            
            $query = "insert into user (userName, userEmail, userPhone, userPassword, userType, userStatus,createdAt) value ('".$_POST['userName']."','".$_POST['userEmail']."','".$_POST['userPhone']."','".md5($_POST['userPassword'])."',2,1,'".$datetime."') ";
            $result = $con->query($query);

            if ($result == 1) {
                $_SESSION['userRegisterSuccessMsg'] = 'User registered successfully!';
                header("Location:login");
            } else {
                echo json_encode(array("flag"=>0));  
            }
        }
    break;
    
    case 'login': 
        session_unset();
        
        $query = "SELECT userId, userName, userEmail, userPhone, userType, userStatus FROM user WHERE userEmail = '".$_POST['userEmail']."' AND userPassword = '".md5($_POST['userPassword'])."' AND userStatus <> 2 ";
        $result = $con->query($query);
        $result_data = mysqli_fetch_assoc($result); 
        
        if (!isset($result_data['userId'])) {
            $_SESSION['userLoginInvalidMsg'] = 'Invalid Username or Password!';
            header("Location:login");
        } else if($result_data['userStatus'] == 0) {
            $_SESSION['userLoginInactiveMsg'] = 'Your Account is Inactive!';
            header("Location:login");
        } else {
            $_SESSION['userId'] = $result_data['userId'];
            $_SESSION['userName'] = $result_data['userName'];
            $_SESSION['userEmail'] = $result_data['userEmail'];
            $_SESSION['userPhone'] = $result_data['userPhone'];
            $_SESSION['userType'] = $result_data['userType'];
            $_SESSION['userStatus'] = $result_data['userStatus'];

            if($result_data['userType'] == 1) {
                header("Location:dashboard");
            } else {
                header("Location:booking");
            }
        }

    break;

    default: 
        header("Location:login");
}
?>