<?php error_reporting(0);
    include('config/define.php');
    session_start();
    if($_SESSION['userId'] != null) { 
        if($_SESSION['userType'] == 1) { 
            echo "<script>window.location.href='".BASE_URL_PATH.'dashboard'."'</script>";
        } else if($_SESSION['userType'] == 2) { 
            echo "<script>window.location.href='".BASE_URL_PATH.'booking'."'</script>";
        }
    }
?>

<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Studio Booking - Login</title>

    <link rel="shortcut icon" href="assets/img/logo.jpg">

    <!-- Custom fonts for this template-->
    <link href="assets/vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
    <link
        href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i"
        rel="stylesheet">

    <!-- Custom styles for this template-->
    <link href="assets/css/sb-admin-2.min.css" rel="stylesheet">

</head>

<body class="bg-gradient-primary">

    <div class="container">

        <!-- Outer Row -->
        <div class="row justify-content-center">

            <div class="col-xl-5 col-lg-6 col-md-4">

                <div class="card o-hidden border-0 shadow-lg my-5">
                    <div class="card-body p-0">
                        <!-- Nested Row within Card Body -->
                        <div class="row">
                            
                            <div class="col-lg-12">
                                <div class="p-5">
                                    <div class="text-center">
                                        <h1 class="h4 text-gray-900 mb-4">Welcome Back!</h1>
                                    </div>
                                    <form class="user needs-validation" id="user-login-form" novalidate action="authenticate" method="post">

                                        <input type="hidden" name="action" value="login">

                                        <div class="form-group">
                                            <input type="email" class="form-control form-control-user" id="userEmail" name="userEmail" placeholder="Email Id" required maxlength="100" value="<?php echo $_SESSION['userEmailRegister']; ?>">
                                            <div class="valid-feedback">
                                                Looks good!
                                            </div>
                                            <div class="invalid-feedback">
                                                Invalid E-Mail Id.
                                            </div>
                                        </div>

                                        <div class="form-group">
                                            <input type="password" class="form-control form-control-user" id="userPassword" name="userPassword" placeholder="Password" required minlength="6" maxlength="12">
                                            <div class="valid-feedback">
                                                Looks good!
                                            </div>
                                            <div class="invalid-feedback">
                                                Please enter the password with 6 to 12 characters.
                                            </div>
                                        </div>
                                        <input type="submit" class="btn btn-primary btn-user btn-block" value="Login" />
                                    </form>
                                    <hr>
                                    <div class="text-center">
                                        <a href="register">Not a member? Register</a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

            </div>

        </div>

    </div>

    <!-- Bootstrap core JavaScript-->
    <script src="assets/vendor/jquery/jquery.min.js"></script>
    <script src="assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

    <!-- Core plugin JavaScript-->
    <script src="assets/vendor/jquery-easing/jquery.easing.min.js"></script>

    <!-- Custom scripts for all pages-->
    <script src="assets/js/sb-admin-2.min.js"></script>

    <script>
        // Example starter JavaScript for disabling form submissions if there are invalid fields
        (function () {
        'use strict'

        // Fetch all the forms we want to apply custom Bootstrap validation styles to
        var forms = document.querySelectorAll('.needs-validation')

        // Loop over them and prevent submission
        Array.prototype.slice.call(forms)
            .forEach(function (form) {
            form.addEventListener('submit', function (event) {

                if (!form.checkValidity()) {
                    event.preventDefault()
                    event.stopPropagation()
                }

                form.classList.add('was-validated')
            }, false)
            })
        })();

        $(document).ready(function() { 
            var registerSuccess = "<?php echo $_SESSION['userRegisterSuccessMsg']; ?>";
            if(registerSuccess != '') {
                alert(registerSuccess);
                <?php unset($_SESSION['userRegisterSuccessMsg']); ?>
            }

            var loginInvalid = "<?php echo $_SESSION['userLoginInvalidMsg']; ?>";
            if(loginInvalid != '') {
                alert(loginInvalid);
                <?php unset($_SESSION['userLoginInvalidMsg']); ?>
            }

            var loginInactive = "<?php echo $_SESSION['userLoginInactiveMsg']; ?>";
            if(loginInactive != '') {
                alert(loginInactive);
                <?php unset($_SESSION['userLoginInactiveMsg']); ?>
            }
        });
    </script>

</body>

</html>