<?php 
    define('BASE_URL_PATH','http://localhost/studio_booking/');
?>