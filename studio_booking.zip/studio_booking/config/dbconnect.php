<?php 

$hostName = "localhost";
$userName = "root";
$passWord = "";
$dataBase = "studio_booking";

$con = mysqli_connect($hostName,$userName,$passWord,$dataBase);

if(mysqli_connect_errno()) {
	echo "Failed to connect MySQL : ".mysqli_connect_errno();
	exit;
}

?>