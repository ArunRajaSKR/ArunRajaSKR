<?php 
    include('common/header.php');
    require_once('config/dbconnect.php');

    session_start();
    if($_SESSION['userId'] == null) { 
        echo "<script>window.location.href='".BASE_URL_PATH.'login'."'</script>";
    }

    $query = "SELECT (SELECT COUNT(bookingId) FROM booking WHERE bookingStatus = 1) AS bookedTicket, (SELECT COUNT(bookingId) FROM booking WHERE bookingStatus = 2) AS deactiveTicket";
    $result = $con->query($query);
    $ticket_count = mysqli_fetch_assoc($result);
    
    $total_tickets = 25;
    $booked_tickets = $ticket_count['bookedTicket'];
    $deactive_tickets = $ticket_count['deactiveTicket'];
    $available_tickets = $total_tickets - ($booked_tickets + $deactive_tickets)
?>

	<!-- Begin Page Content -->
                <div class="container-fluid">

                    <!-- Page Heading -->
                    <div class="d-sm-flex align-items-center justify-content-between mb-4">
                        <h1 class="h3 mb-0 text-gray-800">Dashboard</h1>
                    </div>

                    <!-- Content Row -->
                    <div class="row">

                        <!-- Total (Tickets) Card Example -->
                        <div class="col-xl-3 col-md-6 mb-4">
                            <div class="card border-left-info shadow h-100 py-2">
                                <div class="card-body">
                                    <div class="row no-gutters align-items-center">
                                        <div class="col mr-2">
                                            <div class="text-xs font-weight-bold text-info text-uppercase mb-1">
                                                Total Tickets</div>
                                            <div class="h5 mb-0 font-weight-bold text-gray-800"><?php echo $total_tickets; ?></div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <!-- Booked (Tickets) Card Example -->
                        <div class="col-xl-3 col-md-6 mb-4">
                            <div class="card border-left-success shadow h-100 py-2">
                                <div class="card-body">
                                    <div class="row no-gutters align-items-center">
                                        <div class="col mr-2">
                                            <div class="text-xs font-weight-bold text-success text-uppercase mb-1">
                                                Booked Tickets</div>
                                            <div class="h5 mb-0 font-weight-bold text-gray-800"><?php echo $booked_tickets; ?></div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <!-- Available (Ticket) Card Example -->
                        <div class="col-xl-3 col-md-6 mb-4">
                            <div class="card border-left-secondary shadow h-100 py-2">
                                <div class="card-body">
                                    <div class="row no-gutters align-items-center">
                                        <div class="col mr-2">
                                            <div class="text-xs font-weight-bold text-secondary text-uppercase mb-1">Available Tickets
                                            </div>
                                            <div class="h5 mb-0 font-weight-bold text-gray-800"><?php echo $available_tickets; ?></div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <!-- Deactivated (Tickets) Card Example -->
                        <div class="col-xl-3 col-md-6 mb-4">
                            <div class="card border-left-danger shadow h-100 py-2">
                                <div class="card-body">
                                    <div class="row no-gutters align-items-center">
                                        <div class="col mr-2">
                                            <div class="text-xs font-weight-bold text-danger text-uppercase mb-1">
                                                Deactivated Tickets</div>
                                            <div class="h5 mb-0 font-weight-bold text-gray-800"><?php echo $deactive_tickets; ?></div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Content Row -->

<?php include('common/footer.php'); ?>