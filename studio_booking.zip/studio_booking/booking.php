<?php 
	include('common/header.php'); 
	require_once('config/dbconnect.php');

	session_start();
    if($_SESSION['userId'] == null) { 
        echo "<script>window.location.href='".BASE_URL_PATH.'login'."'</script>";
    }
	
	$query = "SELECT userId, seatNo, bookingStatus FROM booking";
    $result_data = $con->query($query);
	
	$data = array();
	while($result = $result_data->fetch_assoc()) {
		$data[$result['seatNo']]['userId'] = $result['userId'];
		$data[$result['seatNo']]['bookingStatus'] = $result['bookingStatus'];
	}



	if($data['S1']['bookingStatus'] == 1) {
		$s1_cls = 'btn-success';
		$s1_value = 'S1_1';
	} elseif ($data['S1']['bookingStatus'] == 2) {
		$s1_cls = 'btn-danger';
		$s1_value = 'S1_2'; 
	} else { 
		$s1_cls = 'btn-light';
		$s1_value = 'S1_0';
	 }

	if($data['S2']['bookingStatus'] == 1) {
		$s2_cls = 'btn-success';
		$s2_value = 'S2_1';
	} elseif ($data['S2']['bookingStatus'] == 2) {
		$s2_cls = 'btn-danger';
		$s2_value = 'S2_2'; 
	} else { 
		$s2_cls = 'btn-light';
		$s2_value = 'S2_0';
	} 

	if($data['S3']['bookingStatus'] == 1) {
		$s3_cls = 'btn-success';
		$s3_value = 'S3_1';
	} elseif ($data['S3']['bookingStatus'] == 2) {
		$s3_cls = 'btn-danger';
		$s3_value = 'S3_2'; 
	} else { 
		$s3_cls = 'btn-light';
		$s3_value = 'S3_0';
	}
	
	if($data['S4']['bookingStatus'] == 1) {
		$s4_cls = 'btn-success';
		$s4_value = 'S4_1';
	} elseif ($data['S4']['bookingStatus'] == 2) {
		$s4_cls = 'btn-danger';
		$s4_value = 'S4_2'; 
	} else { 
		$s4_cls = 'btn-light';
		$s4_value = 'S4_0';
	}

	if($data['S5']['bookingStatus'] == 1) {
		$s5_cls = 'btn-success';
		$s5_value = 'S5_1';
	} elseif ($data['S5']['bookingStatus'] == 2) {
		$s5_cls = 'btn-danger';
		$s5_value = 'S5_2'; 
	} else { 
		$s5_cls = 'btn-light';
		$s5_value = 'S5_0';
	} 
	
	if($data['S6']['bookingStatus'] == 1) {
		$s6_cls = 'btn-success';
		$s6_value = 'S6_1';
	} elseif ($data['S6']['bookingStatus'] == 2) {
		$s6_cls = 'btn-danger';
		$s6_value = 'S6_2'; 
	} else { 
		$s6_cls = 'btn-light';
		$s6_value = 'S6_0';
	 }

	if($data['S7']['bookingStatus'] == 1) {
		$s7_cls = 'btn-success';
		$s7_value = 'S7_1';
	} elseif ($data['S7']['bookingStatus'] == 2) {
		$s7_cls = 'btn-danger';
		$s7_value = 'S7_2'; 
	} else { 
		$s7_cls = 'btn-light';
		$s7_value = 'S7_0';
	} 

	if($data['S8']['bookingStatus'] == 1) {
		$s8_cls = 'btn-success';
		$s8_value = 'S8_1';
	} elseif ($data['S8']['bookingStatus'] == 2) {
		$s8_cls = 'btn-danger';
		$s8_value = 'S8_2'; 
	} else { 
		$s8_cls = 'btn-light';
		$s8_value = 'S8_0';
	}
	
	if($data['S9']['bookingStatus'] == 1) {
		$s9_cls = 'btn-success';
		$s9_value = 'S9_1';
	} elseif ($data['S9']['bookingStatus'] == 2) {
		$s9_cls = 'btn-danger';
		$s9_value = 'S9_2'; 
	} else { 
		$s9_cls = 'btn-light';
		$s9_value = 'S9_0';
	}

	if($data['S10']['bookingStatus'] == 1) {
		$s10_cls = 'btn-success';
		$s10_value = 'S10_1';
	} elseif ($data['S10']['bookingStatus'] == 2) {
		$s10_cls = 'btn-danger';
		$s10_value = 'S10_2'; 
	} else { 
		$s10_cls = 'btn-light';
		$s10_value = 'S10_0';
	}

	if($data['S11']['bookingStatus'] == 1) {
		$s11_cls = 'btn-success';
		$s11_value = 'S11_1';
	} elseif ($data['S11']['bookingStatus'] == 2) {
		$s11_cls = 'btn-danger';
		$s11_value = 'S11_2'; 
	} else { 
		$s11_cls = 'btn-light';
		$s11_value = 'S11_0';
	 }

	if($data['S12']['bookingStatus'] == 1) {
		$s12_cls = 'btn-success';
		$s12_value = 'S12_1';
	} elseif ($data['S12']['bookingStatus'] == 2) {
		$s12_cls = 'btn-danger';
		$s12_value = 'S12_2'; 
	} else { 
		$s12_cls = 'btn-light';
		$s12_value = 'S12_0';
	} 

	if($data['S13']['bookingStatus'] == 1) {
		$s13_cls = 'btn-success';
		$s13_value = 'S13_1';
	} elseif ($data['S13']['bookingStatus'] == 2) {
		$s13_cls = 'btn-danger';
		$s13_value = 'S13_2'; 
	} else { 
		$s13_cls = 'btn-light';
		$s13_value = 'S13_0';
	}
	
	if($data['S14']['bookingStatus'] == 1) {
		$s14_cls = 'btn-success';
		$s14_value = 'S14_1';
	} elseif ($data['S14']['bookingStatus'] == 2) {
		$s14_cls = 'btn-danger';
		$s14_value = 'S14_2'; 
	} else { 
		$s14_cls = 'btn-light';
		$s14_value = 'S14_0';
	}

	if($data['S15']['bookingStatus'] == 1) {
		$s15_cls = 'btn-success';
		$s15_value = 'S15_1';
	} elseif ($data['S15']['bookingStatus'] == 2) {
		$s15_cls = 'btn-danger';
		$s15_value = 'S15_2'; 
	} else { 
		$s15_cls = 'btn-light';
		$s15_value = 'S15_0';
	}

	if($data['S16']['bookingStatus'] == 1) {
		$s16_cls = 'btn-success';
		$s16_value = 'S16_1';
	} elseif ($data['S16']['bookingStatus'] == 2) {
		$s16_cls = 'btn-danger';
		$s16_value = 'S16_2'; 
	} else { 
		$s16_cls = 'btn-light';
		$s16_value = 'S16_0';
	 }

	if($data['S17']['bookingStatus'] == 1) {
		$s17_cls = 'btn-success';
		$s17_value = 'S17_1';
	} elseif ($data['S17']['bookingStatus'] == 2) {
		$s17_cls = 'btn-danger';
		$s17_value = 'S17_2'; 
	} else { 
		$s17_cls = 'btn-light';
		$s17_value = 'S17_0';
	} 

	if($data['S18']['bookingStatus'] == 1) {
		$s18_cls = 'btn-success';
		$s18_value = 'S18_1';
	} elseif ($data['S18']['bookingStatus'] == 2) {
		$s18_cls = 'btn-danger';
		$s18_value = 'S18_2'; 
	} else { 
		$s18_cls = 'btn-light';
		$s18_value = 'S18_0';
	}
	
	if($data['S19']['bookingStatus'] == 1) {
		$s19_cls = 'btn-success';
		$s19_value = 'S19_1';
	} elseif ($data['S19']['bookingStatus'] == 2) {
		$s19_cls = 'btn-danger';
		$s19_value = 'S19_2'; 
	} else { 
		$s19_cls = 'btn-light';
		$s19_value = 'S19_0';
	}

	if($data['S20']['bookingStatus'] == 1) {
		$s20_cls = 'btn-success';
		$s20_value = 'S20_1';
	} elseif ($data['S20']['bookingStatus'] == 2) {
		$s20_cls = 'btn-danger';
		$s20_value = 'S20_2'; 
	} else { 
		$s20_cls = 'btn-light';
		$s20_value = 'S20_0';
	}

	if($data['S21']['bookingStatus'] == 1) {
		$s21_cls = 'btn-success';
		$s21_value = 'S21_1';
	} elseif ($data['S21']['bookingStatus'] == 2) {
		$s21_cls = 'btn-danger';
		$s21_value = 'S21_2'; 
	} else { 
		$s21_cls = 'btn-light';
		$s21_value = 'S21_0';
	 }

	if($data['S22']['bookingStatus'] == 1) {
		$s22_cls = 'btn-success';
		$s22_value = 'S22_1';
	} elseif ($data['S22']['bookingStatus'] == 2) {
		$s22_cls = 'btn-danger';
		$s22_value = 'S22_2'; 
	} else { 
		$s22_cls = 'btn-light';
		$s22_value = 'S22_0';
	} 

	if($data['S23']['bookingStatus'] == 1) {
		$s23_cls = 'btn-success';
		$s23_value = 'S23_1';
	} elseif ($data['S23']['bookingStatus'] == 2) {
		$s23_cls = 'btn-danger';
		$s23_value = 'S23_2'; 
	} else { 
		$s23_cls = 'btn-light';
		$s23_value = 'S23_0';
	}
	
	if($data['S24']['bookingStatus'] == 1) {
		$s24_cls = 'btn-success';
		$s24_value = 'S24_1';
	} elseif ($data['S24']['bookingStatus'] == 2) {
		$s24_cls = 'btn-danger';
		$s24_value = 'S24_2'; 
	} else { 
		$s24_cls = 'btn-light';
		$s24_value = 'S24_0';
	}

	if($data['S25']['bookingStatus'] == 1) {
		$s25_cls = 'btn-success';
		$s25_value = 'S25_1';
	} elseif ($data['S25']['bookingStatus'] == 2) {
		$s25_cls = 'btn-danger';
		$s25_value = 'S25_2'; 
	} else { 
		$s25_cls = 'btn-light';
		$s25_value = 'S25_0';
	}

?>

	<!-- Begin Page Content -->
    <div class="container-fluid">

        <!-- Page Heading -->
        <h1 class="h3 mb-2 text-gray-800">Booking Management</h1>

        <!-- DataTales Example -->
        <div class="card shadow mb-4">
            <div class="card-header py-3">
                <h6 class="m-0 font-weight-bold text-primary">Seating Arrangement View
                </h6>
            </div>
            <div class="card-body bg-seat-arrangement">
                <div class="table">

					<div class="row">
						<div class="form-group col-xs-12 col-sm-12 col-md-12 col-lg-12 col-xl-12">
							<div class="row">
								<div class="col-xs-1 col-sm-1 col-md-1 col-lg-1 col-xl-1"></div>
							    <div class="col-xs-2 col-sm-2 col-md-2 col-lg-2 col-xl-2">
									<button type="button" class="form-control btn <?php echo $s1_cls; ?> btn-seat" id="s1" name="s1" value="<?php echo $s1_value; ?>">S1</button>
							  	</div>
								<div class="col-xs-2 col-sm-2 col-md-2 col-lg-2 col-xl-2">
									<button type="button" class="form-control btn <?php echo $s2_cls; ?> btn-seat" id="s2" name="s2" value="<?php echo $s2_value; ?>">S2</button>
							  	</div>
								<div class="col-xs-2 col-sm-2 col-md-2 col-lg-2 col-xl-2">
									<button type="button" class="form-control btn <?php echo $s3_cls; ?> btn-seat" id="s3" name="s3" value="<?php echo $s3_value; ?>">S3</button>
							  	</div>
								<div class="col-xs-2 col-sm-2 col-md-2 col-lg-2 col-xl-2">
									<button type="button" class="form-control btn <?php echo $s4_cls; ?> btn-seat" id="s4" name="s4" value="<?php echo $s4_value; ?>">S4</button>
							  	</div>
								<div class="col-xs-2 col-sm-2 col-md-2 col-lg-2 col-xl-2">
									<button type="button" class="form-control btn <?php echo $s5_cls; ?> btn-seat" id="s5" name="s5" value="<?php echo $s5_value; ?>">S5</button>
							  	</div>
								<div class="col-xs-1 col-sm-1 col-md-1 col-lg-1 col-xl-1"></div>
						  	</div>
					  	</div>
					</div>

					<div class="row">
						<div class="form-group col-xs-12 col-sm-12 col-md-12 col-lg-12 col-xl-12">
							<div class="row">
								<div class="col-xs-1 col-sm-1 col-md-1 col-lg-1 col-xl-1"></div>
							    <div class="col-xs-2 col-sm-2 col-md-2 col-lg-2 col-xl-2">
							    	<button type="button" class="form-control btn <?php echo $s6_cls; ?> btn-seat" id="s6" name="s6" value="<?php echo $s6_value; ?>">S6</button>
							  	</div>
								<div class="col-xs-2 col-sm-2 col-md-2 col-lg-2 col-xl-2">
									<button type="button" class="form-control btn <?php echo $s7_cls; ?> btn-seat" id="s7" name="s7" value="<?php echo $s7_value; ?>">S7</button>
							  	</div>
								<div class="col-xs-2 col-sm-2 col-md-2 col-lg-2 col-xl-2">
									<button type="button" class="form-control btn <?php echo $s8_cls; ?> btn-seat" id="s8" name="s8" value="<?php echo $s8_value; ?>">S8</button>
							  	</div>
								<div class="col-xs-2 col-sm-2 col-md-2 col-lg-2 col-xl-2">
									<button type="button" class="form-control btn <?php echo $s9_cls; ?> btn-seat" id="s9" name="s9" value="<?php echo $s9_value; ?>">S9</button>
							  	</div>
								<div class="col-xs-2 col-sm-2 col-md-2 col-lg-2 col-xl-2">
									<button type="button" class="form-control btn <?php echo $s10_cls; ?> btn-seat" id="s10" name="s10" value="<?php echo $s10_value; ?>">S10</button>
							  	</div>
								<div class="col-xs-1 col-sm-1 col-md-1 col-lg-1 col-xl-1"></div>
						  	</div>
					  	</div>
					</div>

					<div class="row">
						<div class="form-group col-xs-12 col-sm-12 col-md-12 col-lg-12 col-xl-12">
							<div class="row">
								<div class="col-xs-1 col-sm-1 col-md-1 col-lg-1 col-xl-1"></div>
							    <div class="col-xs-2 col-sm-2 col-md-2 col-lg-2 col-xl-2">
							    	<button type="button" class="form-control btn <?php echo $s11_cls; ?> btn-seat" id="s11" name="s11" value="<?php echo $s11_value; ?>">S11</button>
							  	</div>
								<div class="col-xs-2 col-sm-2 col-md-2 col-lg-2 col-xl-2">
									<button type="button" class="form-control btn <?php echo $s12_cls; ?> btn-seat" id="s12" name="s12" value="<?php echo $s12_value; ?>">S12</button>
							  	</div>
								<div class="col-xs-2 col-sm-2 col-md-2 col-lg-2 col-xl-2">
									<button type="button" class="form-control btn <?php echo $s13_cls; ?> btn-seat" id="s13" name="s13" value="<?php echo $s13_value; ?>">S13</button>
							  	</div>
								<div class="col-xs-2 col-sm-2 col-md-2 col-lg-2 col-xl-2">
									<button type="button" class="form-control btn <?php echo $s14_cls; ?> btn-seat" id="s14" name="s14" value="<?php echo $s14_value; ?>">S14</button>
							  	</div>
								<div class="col-xs-2 col-sm-2 col-md-2 col-lg-2 col-xl-2">
									<button type="button" class="form-control btn <?php echo $s15_cls; ?> btn-seat" id="s15" name="s15" value="<?php echo $s15_value; ?>">S15</button>
							  	</div>
								<div class="col-xs-1 col-sm-1 col-md-1 col-lg-1 col-xl-1"></div>
						  	</div>
					  	</div>
					</div>

					<div class="row">
						<div class="form-group col-xs-12 col-sm-12 col-md-12 col-lg-12 col-xl-12">
							<div class="row">
								<div class="col-xs-1 col-sm-1 col-md-1 col-lg-1 col-xl-1"></div>
							    <div class="col-xs-2 col-sm-2 col-md-2 col-lg-2 col-xl-2">
							    	<button type="button" class="form-control btn <?php echo $s16_cls; ?> btn-seat" id="s16" name="s16" value="<?php echo $s16_value; ?>">S16</button>
							  	</div>
								<div class="col-xs-2 col-sm-2 col-md-2 col-lg-2 col-xl-2">
									<button type="button" class="form-control btn <?php echo $s17_cls; ?> btn-seat" id="s17" name="s17" value="<?php echo $s17_value; ?>">S17</button>
							  	</div>
								<div class="col-xs-2 col-sm-2 col-md-2 col-lg-2 col-xl-2">
									<button type="button" class="form-control btn <?php echo $s18_cls; ?> btn-seat" id="s18" name="s18" value="<?php echo $s18_value; ?>">S18</button>
							  	</div>
								<div class="col-xs-2 col-sm-2 col-md-2 col-lg-2 col-xl-2">
									<button type="button" class="form-control btn <?php echo $s19_cls; ?> btn-seat" id="s19" name="s19" value="<?php echo $s19_value; ?>">S19</button>
							  	</div>
								<div class="col-xs-2 col-sm-2 col-md-2 col-lg-2 col-xl-2">
									<button type="button" class="form-control btn <?php echo $s20_cls; ?> btn-seat" id="s20" name="s20" value="<?php echo $s20_value; ?>">S20</button>
							  	</div>
								<div class="col-xs-1 col-sm-1 col-md-1 col-lg-1 col-xl-1"></div>
						  	</div>
					  	</div>
					</div>

					<div class="row">
						<div class="form-group col-xs-12 col-sm-12 col-md-12 col-lg-12 col-xl-12">
							<div class="row">
								<div class="col-xs-1 col-sm-1 col-md-1 col-lg-1 col-xl-1"></div>
							    <div class="col-xs-2 col-sm-2 col-md-2 col-lg-2 col-xl-2">
							    	<button type="button" class="form-control btn <?php echo $s21_cls; ?> btn-seat" id="s21" name="s21" value="<?php echo $s21_value; ?>">S21</button>
							  	</div>
								<div class="col-xs-2 col-sm-2 col-md-2 col-lg-2 col-xl-2">
									<button type="button" class="form-control btn <?php echo $s22_cls; ?> btn-seat" id="s22" name="s22" value="<?php echo $s22_value; ?>">S22</button>
							  	</div>
								<div class="col-xs-2 col-sm-2 col-md-2 col-lg-2 col-xl-2">
									<button type="button" class="form-control btn <?php echo $s23_cls; ?> btn-seat" id="s23" name="s23" value="<?php echo $s23_value; ?>">S23</button>
							  	</div>
								<div class="col-xs-2 col-sm-2 col-md-2 col-lg-2 col-xl-2">
									<button type="button" class="form-control btn <?php echo $s24_cls; ?> btn-seat" id="s24" name="s24" value="<?php echo $s24_value; ?>">S24</button>
							  	</div>
								<div class="col-xs-2 col-sm-2 col-md-2 col-lg-2 col-xl-2">
									<button type="button" class="form-control btn <?php echo $s25_cls; ?> btn-seat" id="s25" name="s25" value="<?php echo $s25_value; ?>">S25</button>
							  	</div>
								<div class="col-xs-1 col-sm-1 col-md-1 col-lg-1 col-xl-1"></div>
						  	</div>
					  	</div>
					</div>


                </div>
            </div>
        </div>

    </div>
    <!-- /.container-fluid -->

	<!-- Booking Confirm Modal-->
	<div class="modal fade" id="bookingConfirmModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
		<div class="modal-dialog" role="document">
			<div class="modal-content">
				<div class="modal-header">
					<h5 class="modal-title" id="exampleModalLabel">Are you sure, you want to book the seat <span id="book-confirm-seat"></span>?</h5>
					<button class="close" type="button" data-dismiss="modal" aria-label="Close">
						<span aria-hidden="true">×</span>
					</button>
				</div>
				<div class="modal-body">
					<div class="row">
						<div class="form-group col-12">
							<div class="row">
							  	<div class="col-xs-12 col-sm-12 col-md-3 col-lg-3 col-xl-3">
							    	<label class="label-field">User Name</label>
							    </div>
							    <div class="col-xs-12 col-sm-12 col-md-9 col-lg-9 col-xl-9">
							    	<input type="text" class="form-control" value="<?php echo $_SESSION['userName']; ?>" readonly />
							  	</div>
							</div>
						</div>
					</div>
					<div class="row">
						<div class="form-group col-12">
							<div class="row">
							  	<div class="col-xs-12 col-sm-12 col-md-3 col-lg-3 col-xl-3">
							    	<label class="label-field">User Email</label>
							    </div>
							    <div class="col-xs-12 col-sm-12 col-md-9 col-lg-9 col-xl-9">
							    	<input type="text" class="form-control" value="<?php echo $_SESSION['userEmail']; ?>" readonly />
							  	</div>
							</div>
						</div>
					</div>
					<div class="row">
						<div class="form-group col-12">
							<div class="row">
							  	<div class="col-xs-12 col-sm-12 col-md-3 col-lg-3 col-xl-3">
							    	<label class="label-field">User Phone</label>
							    </div>
							    <div class="col-xs-12 col-sm-12 col-md-9 col-lg-9 col-xl-9">
							    	<input type="text" class="form-control" value="<?php echo $_SESSION['userPhone']; ?>" readonly />
							  	</div>
							</div>
						</div>
					</div>
				</div>
				<div class="modal-footer">
					<button class="btn btn-secondary" type="button" data-dismiss="modal">Cancel</button>
					<button class="btn btn-primary" type="button" id="confirm-booking">Confirm</button>
				</div>
			</div>
		</div>
	</div>

	<!-- Deactivate Confirm Modal-->
	<div class="modal fade" id="deactivateConfirmModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
		<div class="modal-dialog" role="document">
			<div class="modal-content">
				<div class="modal-header">
					<h5 class="modal-title" id="exampleModalLabel">Are you sure, you want to deactivate the seat <span id="deactivate-confirm-seat"></span>?</h5>
					<button class="close" type="button" data-dismiss="modal" aria-label="Close">
						<span aria-hidden="true">×</span>
					</button>
				</div>
				<div class="modal-body">
					<div class="row">
						<div class="form-group col-12">
							<div class="row">
							  	<div class="col-xs-12 col-sm-12 col-md-3 col-lg-3 col-xl-3">
							    	<label class="label-field">User Name</label>
							    </div>
							    <div class="col-xs-12 col-sm-12 col-md-9 col-lg-9 col-xl-9">
							    	<input type="text" class="form-control" value="<?php echo $_SESSION['userName']; ?>" readonly />
							  	</div>
							</div>
						</div>
					</div>
					<div class="row">
						<div class="form-group col-12">
							<div class="row">
							  	<div class="col-xs-12 col-sm-12 col-md-3 col-lg-3 col-xl-3">
							    	<label class="label-field">User Email</label>
							    </div>
							    <div class="col-xs-12 col-sm-12 col-md-9 col-lg-9 col-xl-9">
							    	<input type="text" class="form-control" value="<?php echo $_SESSION['userEmail']; ?>" readonly />
							  	</div>
							</div>
						</div>
					</div>
					<div class="row">
						<div class="form-group col-12">
							<div class="row">
							  	<div class="col-xs-12 col-sm-12 col-md-3 col-lg-3 col-xl-3">
							    	<label class="label-field">User Phone</label>
							    </div>
							    <div class="col-xs-12 col-sm-12 col-md-9 col-lg-9 col-xl-9">
							    	<input type="text" class="form-control" value="<?php echo $_SESSION['userPhone']; ?>" readonly />
							  	</div>
							</div>
						</div>
					</div>
				</div>
				<div class="modal-footer">
					<button class="btn btn-secondary" type="button" data-dismiss="modal">Cancel</button>
					<button class="btn btn-primary" type="button" id="confirm-deactivate">Confirm</button>
				</div>
			</div>
		</div>
	</div>

<?php include('common/footer.php'); ?>	

<script>
	$(".btn-seat").click(function() {
		var user_type = "<?php echo $_SESSION['userType']; ?>";
		var seat_data = this.value;
		seat_data = seat_data.split('_');
		var seat_no = seat_data[0];
		var seat_flag = seat_data[1];
		
		if((seat_flag == 0) && (user_type == 2)) {
			$("#book-confirm-seat").html(seat_no);
			$("#bookingConfirmModal").modal('show');
		}
		if((seat_flag == 0) && (user_type == 1)) {
			$("#deactivate-confirm-seat").html(seat_no);
			$("#deactivateConfirmModal").modal('show');
		}
	});

	$("#confirm-booking").click(function() {
		var seat_no = $("#book-confirm-seat").html();

		$.ajax({
         	url  : 'process.php',
         	type : 'post',
         	data : 'action=booking&seat_no='+seat_no,	
         	dataType : 'json',
         	success : function(response) {
				if(response.last_id > 0) {
					seat_no = seat_no.toLowerCase();
					$("#"+seat_no).removeClass('btn-light');
					$("#"+seat_no).addClass('btn-success');
					$("#bookingConfirmModal").modal('hide');
				}
         	}
      	});
	});

	$("#confirm-deactivate").click(function() {
		var seat_no = $("#deactivate-confirm-seat").html();

		$.ajax({
         	url  : 'process.php',
         	type : 'post',
         	data : 'action=deactivate&seat_no='+seat_no,	
         	dataType : 'json',
         	success : function(response) {
				if(response.last_id > 0) {
					seat_no = seat_no.toLowerCase();
					$("#"+seat_no).removeClass('btn-light');
					$("#"+seat_no).addClass('btn-danger');
					$("#deactivateConfirmModal").modal('hide');
				}
         	}
      	});
	});
</script>